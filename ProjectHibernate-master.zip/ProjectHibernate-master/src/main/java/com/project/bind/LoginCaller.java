package com.project.bind;

import com.google.inject.Inject;
import com.project.service.LoginService;



